 The SQL Scripts plugin allows you to save and restore SQL scripts from a
 text file. It will also allow you to generate CREATE TABLE and INSERT scripts
 for existing tables in your database.