This plugin provides variable replacement in SQL statements.

Just replace variable parts of your SQL with variables starting
with a colon and a name (e.g. ":variable"). Then you will be asked
for the value when you execute the statement.